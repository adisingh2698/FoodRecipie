package com.example.project.Constants;

public abstract class Messages {
    public static String passwordAndConfirmPasswordNotMatched = "Password and Confirm password not matched";
    public static String userAlreadyExists = "User already exists";
}
