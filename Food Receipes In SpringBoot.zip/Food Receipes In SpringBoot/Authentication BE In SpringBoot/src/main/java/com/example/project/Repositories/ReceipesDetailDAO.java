package com.example.project.Repositories;

import com.example.project.Models.ReceipesDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReceipesDetailDAO extends JpaRepository<ReceipesDetail, Long> {
}
