package com.example.project.Services;

import antlr.ASTNULLType;
import com.example.project.DTO.GetReviewDetailListDAO;
import com.example.project.Models.ProfileDetail;
import com.example.project.Models.ReceipesDetail;
import com.example.project.Models.ReviewDetail;
import com.example.project.Repositories.ReceipesDetailDAO;
import com.example.project.Repositories.ReviewDetailDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    ReceipesDetailDAO receipesDetailDAO;
    ReviewDetailDAO reviewDetailDAO;

    public String AddReceipesDetail(ReceipesDetail request) {

        try {
            receipesDetailDAO.save(request);
            return "Added Receipes Detail Successfully!";

        }catch (Exception ex)
        {
            return ex.getMessage();
        }

    }

    public String UpdateReceipesDetail(ReceipesDetail request){

        try{

            Optional<ReceipesDetail> response = receipesDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==request.getId())
                    .findFirst();

            if(!response.isPresent()) {
                return "Invalid Receipes Id";
            }


            response.get().setUserID(request.getUserID());
            response.get().setName(request.getName());
            response.get().setDescription(request.getDescription());
            response.get().setIngredients(request.getIngredients());
            response.get().setCookingSteps(request.getCookingSteps());
            response.get().setCategory(request.getCategory());
            response.get().setImageUrl(request.getImageUrl());
            response.get().setIsActive(request.getIsActive());
            receipesDetailDAO.save(response.get());

            return "Update Receipes Detail successfully";

        }catch (Exception ex){
            return ex.getMessage();
        }

    }

    public List<ReceipesDetail> GetReceipesDetailList(){

        try{
            return receipesDetailDAO
                    .findAll()
                    .stream()
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String DeleteReceipesDetailL(Long Id){

        try{

            Optional<ReceipesDetail> response = receipesDetailDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Receipes Id";
            }

            receipesDetailDAO.delete(response.get());

            return "Delete Receipes Successfully";

        }catch (Exception ex){
            return null;
        }
    }
    public List<GetReviewDetailListDAO> GetUserReviewList(){
        try{

            List<ReviewDetail> r = reviewDetailDAO
                    .findAll()
                    .stream()
                    .toList();


            List<GetReviewDetailListDAO> getList = new ArrayList<>();
            r.forEach(x->{
                GetReviewDetailListDAO getData = new GetReviewDetailListDAO();
                getData.setId(x.getId());
                getData.setCreatedDate(x.getCreatedDate());
                getData.setReceipeId(x.getReceipeId());
                getData.setUserId(x.getUserId());
                getData.setComment(x.getComment());
                getData.setStatus(x.getStatus());
                Optional<ReceipesDetail> data = receipesDetailDAO.findAll().stream().filter(x1->x1.getId()==x.getReceipeId()).findFirst();
                String Name = "";
                if(data.isEmpty()){
                    Name = "";
                }else{
                    Name = data.get().getName();
                }
                getData.setReceipeName(Name);
                getList.add(getData);
            });
            return getList;

        }catch (Exception ex){
            return null;
        }
    }

}
