package com.example.hotelmanagment;

import com.example.project.Controllers.AdminController;
import com.example.project.Models.ReceipesDetail;
import com.example.project.Services.AdminService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class AdminControllerTest {

	@Mock
	private AdminService adminService;

	@InjectMocks
	private AdminController adminController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void addReceipesDetail() {
		ReceipesDetail receipesDetail = new ReceipesDetail(); // Populate with necessary fields
		when(adminService.AddReceipesDetail(any(ReceipesDetail.class))).thenReturn("Receipes Detail Added Successfully");

		ResponseEntity responseEntity = adminController.AddReceipesDetail(receipesDetail);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		verify(adminService).AddReceipesDetail(any(ReceipesDetail.class));
	}

	@Test
	void updateReceipesDetail() {
		ReceipesDetail receipesDetail = new ReceipesDetail(); // Populate with necessary fields
		when(adminService.UpdateReceipesDetail(any(ReceipesDetail.class))).thenReturn("Receipes Detail Updated Successfully");

		ResponseEntity responseEntity = adminController.UpdateReceipesDetail(receipesDetail);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		verify(adminService).UpdateReceipesDetail(any(ReceipesDetail.class));
	}

	@Test
	void getReceipesDetailList() {
		List<ReceipesDetail> receipesDetails = new ArrayList<>();
		receipesDetails.add(new ReceipesDetail()); // Populate list

		when(adminService.GetReceipesDetailList()).thenReturn(receipesDetails);

		ResponseEntity responseEntity = adminController.GetReceipesDetailList();

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		assertEquals(receipesDetails, responseEntity.getBody());
		verify(adminService).GetReceipesDetailList();
	}

	@Test
	void deleteReceipesDetailL() {
		Long id = 1L; // Example ID
		when(adminService.DeleteReceipesDetailL(id)).thenReturn("Receipes Detail Deleted Successfully");

		ResponseEntity responseEntity = adminController.DeleteReceipesDetailL(id);

		assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
		verify(adminService).DeleteReceipesDetailL(id);
	}
}