package com.example.hotelmanagment;

import com.example.project.Controllers.AuthController;
import com.example.project.DTO.BasicResponseDTO;
import com.example.project.DTO.LoginRequestDTO;
import com.example.project.DTO.LoginResponseDTO;
import com.example.project.Services.AuthenticationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class AuthControllerTest {

    @Mock
    private AuthenticationService authenticationService;

    @InjectMocks
    private AuthController authController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }



    @Test
    public void testLogin_Success() {
        // Mocking the login request DTO
        LoginRequestDTO loginRequestDTO = new LoginRequestDTO();
        loginRequestDTO.setEmail("test@example.com");
        loginRequestDTO.setPassword("password");

        // Mocking the login response DTO
        LoginResponseDTO loginResponseDTO = new LoginResponseDTO();
        loginResponseDTO.setToken("mocked_token");

        // Mocking the authentication service behavior
        when(authenticationService.login("test@example.com", "password"))
                .thenReturn(new BasicResponseDTO<>(true, "Login successful", loginResponseDTO));

        // Calling the login endpoint
        ResponseEntity<?> responseEntity = authController.login(loginRequestDTO);

        // Verifying the response status code
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

        // Verifying the response body
        assertEquals(loginResponseDTO, responseEntity.getBody());
    }

    @Test
    public void testLogin_Failure() {
        // Mocking the login request DTO
        LoginRequestDTO loginRequestDTO = new LoginRequestDTO();
        loginRequestDTO.setEmail("test@example.com");
        loginRequestDTO.setPassword("password");

        // Mocking the authentication service behavior for failure
        when(authenticationService.login("test@example.com", "password"))
                .thenReturn(new BasicResponseDTO<>(false, "Invalid credentials", null));

        // Calling the login endpoint
        ResponseEntity<?> responseEntity = authController.login(loginRequestDTO);

        // Verifying the response status code
        assertEquals(HttpStatus.UNAUTHORIZED, responseEntity.getStatusCode());
    }
    @Test
    void findEmail_withExistingEmail_shouldReturnOk() {
        String email = "test@example.com";
        when(authenticationService.findEmail(anyString())).thenReturn(true);

        ResponseEntity responseEntity = authController.findEmail(email);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        verify(authenticationService).findEmail(anyString());
    }

    @Test
    void changePassword_withValidRequest_shouldReturnOk() {
        String email = "test@example.com";
        String newPassword = "newPassword";
        BasicResponseDTO expectedResponse = new BasicResponseDTO(true, null, "The password has been updated successfully");

        when(authenticationService.changePassword(anyString(), anyString())).thenReturn(expectedResponse);

        ResponseEntity responseEntity = authController.changePassword(email, newPassword);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        verify(authenticationService).changePassword(anyString(), anyString());
    }
}
