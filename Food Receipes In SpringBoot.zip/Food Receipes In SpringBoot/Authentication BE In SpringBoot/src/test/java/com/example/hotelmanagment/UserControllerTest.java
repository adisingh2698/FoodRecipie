package com.example.hotelmanagment;

import com.example.project.DTO.BasicResponseDTO;
import com.example.project.DTO.BasicResponseErrorDTO;
import com.example.project.Models.ProfileDetail;
import com.example.project.Models.ReceipesDetail;
import com.example.project.Models.ReviewDetail;
import com.example.project.Services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.example.project.Controllers.UserController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class UserControllerTest {

    @Mock
    private UserService userService;

    @InjectMocks
    private UserController userController;

    @BeforeEach
    public void setUp() {
        initMocks(this);
    }

    @Test
    public void testAddProfile() throws Exception {
        ProfileDetail profileDetail = new ProfileDetail();
        when(userService.AddProfile(any(ProfileDetail.class))).thenReturn("Profile added successfully");

        ResponseEntity<?> response = userController.AddProfile(profileDetail);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        BasicResponseDTO responseBody = (BasicResponseDTO) response.getBody();
        assertEquals("Profile added successfully", responseBody.getMessage());
    }

    @Test
    public void testUpdateProfile() throws Exception {
        ProfileDetail profileDetail = new ProfileDetail();
        when(userService.UpdateProfile(any(ProfileDetail.class))).thenReturn("Profile updated successfully");

        ResponseEntity<?> response = userController.UpdateProfile(profileDetail);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    public void testGetProfile() throws Exception {
        Long userId = 1L;
        ProfileDetail profileDetail = new ProfileDetail();
        when(userService.GetProfile(userId)).thenReturn(Optional.of(profileDetail));

        ResponseEntity<?> response = userController.GetProfile(userId);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        //assertEquals(profileDetail, response.getBody());
    }

    @Test
    public void testGetProfileNotFound() throws Exception {
        Long userId = 1L;
        when(userService.GetProfile(userId)).thenReturn(null);

        ResponseEntity<?> response = userController.GetProfile(userId);

        // Depending on the desired behavior when a profile is not found, you might want to adjust this test.
        // For instance, if a 404 status is expected, the controller method needs to be adjusted accordingly.
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void testGetReceipesDetailList() {
        List<ReceipesDetail> receipesDetailList = new ArrayList<>();
        // Add some sample ReceipesDetail objects to the list

        when(userService.GetReceipesDetailList()).thenReturn(receipesDetailList);

        ResponseEntity responseEntity = userController.GetReceipesDetailList();

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(receipesDetailList, responseEntity.getBody());
    }

    @Test
    void testGetReceipesByCategory() {
        String keyword = "testKeyword";
        List<ReceipesDetail> receipesByCategoryList = new ArrayList<>();
        // Add some sample ReceipesDetail objects to the list

        when(userService.GetReceipesByCategory(keyword)).thenReturn(receipesByCategoryList);

        ResponseEntity responseEntity = userController.GetReceipesByCategory(keyword);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(receipesByCategoryList, responseEntity.getBody());
    }

    @Test
    void testGetReceipesByKeyword_Success() {
        String keyword = "test";
        List<ReceipesDetail> receipesList = new ArrayList<>();
        // Populate receipesList with test data

        when(userService.GetReceipesByKeyword(anyString())).thenReturn(receipesList);

        ResponseEntity responseEntity = userController.GetReceipesByKeyword(keyword);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(receipesList, responseEntity.getBody());
    }

    @Test
    void testAddUserReview_Success() {
        ReviewDetail reviewDetail = new ReviewDetail();


        String responseMessage = "Review added successfully";
        when(userService.AddUserReview(reviewDetail)).thenReturn(responseMessage);

        ResponseEntity responseEntity = userController.AddUserReview(reviewDetail);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());

    }
}