import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserReviewComponent } from './userreview.component';

